package liçãoMod10;
import java.util.Scanner ;

public class liçãomod10 {
	public static void main(String[] args) {
        double[] notas = {4, 5, 9, 7,};       
        for (int i = 0; i < notas.length; i++) {           
          if (notas[i] >= 0 && notas[i] <= 10) {    
          if (notas[i] >= 7) {
         System.out.println("Nota " + notas[i] + ": Aprovado!");
         } else if (notas[i] >= 5) {
         System.out.println("Nota " + notas[i] + ": Em recuperação.");
         } else {
         System.out.println("Nota " + notas[i] + ": Reprovado.");
          }
         } else {
         System.out.println("Nota inválida na posição " + i + ". A nota deve estar entre 0 e 10.");
    }
   }
  }
}
