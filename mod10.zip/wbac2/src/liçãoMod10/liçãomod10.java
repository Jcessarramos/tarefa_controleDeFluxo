package liçãoMod10;
import java.util.Scanner ;

public class liçãomod10 {
	public static void main(String[] args) {
		  int n1 = 7;
	        int n2 = 8;
	        int n3 = 6;
	        int n4 = 8;
	        int n5 = (n1 + n2 + n3 + n4) / 4;
	        
	        System.out.println("Média das notas: " + n5);

	       
	        if (n5 >= 7) {
	            System.out.println("Aluno aprovado!");
	        } else if (n5 >= 5) {
	            System.out.println("Recuperação");
	        } else {
	            System.out.println("Reprovado");
	        }
    }
   
  }

